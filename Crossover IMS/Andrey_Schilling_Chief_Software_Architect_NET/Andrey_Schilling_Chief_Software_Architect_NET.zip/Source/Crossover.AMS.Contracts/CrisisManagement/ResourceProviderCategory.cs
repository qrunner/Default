﻿namespace Crossover.AMS.Contracts.CrisisManagement
{
    public enum ResourceProviderCategory
    {
        Vendor,
        Volunteer
    }
}