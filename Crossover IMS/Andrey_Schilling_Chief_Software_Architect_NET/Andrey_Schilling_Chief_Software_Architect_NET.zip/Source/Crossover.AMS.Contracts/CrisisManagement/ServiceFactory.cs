﻿namespace Crossover.AMS.Contracts.CrisisManagement
{
    public static class ServiceFactory
    {
        private static ICmsService GetCmsService()
        {
            return null;
        }
    }
}