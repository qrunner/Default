﻿namespace Crossover.AMS.Contracts.CrisisManagement
{
    public interface IResourceCategory : IEntity
    {
        string Name { get; }
    }
}