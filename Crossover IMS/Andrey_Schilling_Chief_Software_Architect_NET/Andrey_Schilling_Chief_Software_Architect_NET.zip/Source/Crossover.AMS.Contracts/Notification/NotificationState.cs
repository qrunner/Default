﻿namespace Crossover.AMS.Contracts.Notification
{
    public enum NotificationState
    {
        InQueue,
        InProcess,
        Complete,
        Error
    }
}