﻿namespace Crossover.AMS.Contracts.TaskPlanning
{
    public enum TaskState
    {
        New,
        InProcess,
        Delayed,
        Closed
    }
}