﻿namespace Crossover.AMS.Contracts
{
    public enum ContactCategory
    {
        Home,
        Work,
        Relative
    }
}