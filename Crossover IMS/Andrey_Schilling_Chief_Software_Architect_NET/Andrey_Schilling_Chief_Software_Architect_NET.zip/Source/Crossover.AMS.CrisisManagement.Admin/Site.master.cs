﻿using System.ComponentModel.DataAnnotations;
using System.Web.DynamicData;
using System.Web.UI.WebControls;

namespace Crossover.AMS.CrisisManagement.Admin
{
    public partial class Site : System.Web.UI.MasterPage
    {

    }
}
