﻿namespace Crossover.AMS.CrisisManagement
{
    public class ResourceProviderContact : Contact
    {
        public virtual ResourceProvider ResourceProvider { get; set; }
    }
}
