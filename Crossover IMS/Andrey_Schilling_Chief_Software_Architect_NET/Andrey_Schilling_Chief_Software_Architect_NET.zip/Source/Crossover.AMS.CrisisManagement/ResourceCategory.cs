﻿using Crossover.AMS.Contracts.CrisisManagement;

namespace Crossover.AMS.CrisisManagement
{
    public class ResourceCategory : Entity, IResourceCategory
    {
        public string Name { get; set; }
    }
}