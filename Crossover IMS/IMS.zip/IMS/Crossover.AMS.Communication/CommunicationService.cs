﻿using System;
using System.Collections.Generic;
using Crossover.AMS.Contracts.Communication;
using Crossover.AMS.Contracts.Messages;

namespace Crossover.AMS.Communication
{
    public class CommunicationService : ICommunicationService
    {
        public void SendConferenceMessage(IConferenceMessage message)
        {
            throw new NotImplementedException();
        }

        public void SendPrivateMessage(IPrivateMessage message)
        {
            Console.WriteLine(message.Text);
        }

        public IEnumerable<IPrivateMessage> GetPrivateMessages(Guid senderSid, Guid recipientSid)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Guid> GetNewPrivateSenders(Guid recipientSid)
        {
            throw new NotImplementedException();
        }

        public void MarkAsReaded(IPrivateMessage message)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<IConferenceMessage> GetConferenceMessages(long conferenceId)
        {
            throw new NotImplementedException();
        }

        public IConference CreateConference(long accidentId, string title)
        {
            Console.WriteLine("Conference {0} created", title);
            return new CommunicationConference {State = ConferenceState.Active, Title = title};
        }

        public void UpdateConference(IConference conference)
        {
            throw new NotImplementedException();
        }

        public void DeleteConference(long conferenceId)
        {
            throw new NotImplementedException();
        }
    }
}