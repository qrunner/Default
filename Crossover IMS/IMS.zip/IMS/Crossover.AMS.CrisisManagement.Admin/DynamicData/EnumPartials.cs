﻿namespace Crossover.AMS.CrisisManagement
{
    public partial class TeamMemberContact
    {
    }
}