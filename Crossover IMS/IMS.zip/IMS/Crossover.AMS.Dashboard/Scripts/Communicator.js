﻿window.onload = function () {
    var service = new Crossover.AMS.Dashboard.CommunicationService();
    alert(service.HelloWorld());

    alert(Crossover.AMS.Dashboard.CommunicationService.HelloWorld());
}