﻿namespace Crossover.AMS.CrisisManagement
{
    public class TeamMemberContact : Contact
    {
        public virtual TeamMember TeamMember { get; set; }
    }
}