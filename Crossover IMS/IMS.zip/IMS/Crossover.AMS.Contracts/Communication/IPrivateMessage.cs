﻿using System;

namespace Crossover.AMS.Contracts.Communication
{
    public interface IPrivateMessage : IMessage
    {
        Guid RecipientSid { get; }

        bool Readed { get; }
    }
}