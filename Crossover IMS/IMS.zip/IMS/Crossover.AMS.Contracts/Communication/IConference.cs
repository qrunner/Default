﻿using System.Runtime.Serialization;

namespace Crossover.AMS.Contracts.Communication
{
    public interface IConference
    {
        long Id { get; }

        string Title { get; set; }

        ConferenceState State { get; set; }
    }
}