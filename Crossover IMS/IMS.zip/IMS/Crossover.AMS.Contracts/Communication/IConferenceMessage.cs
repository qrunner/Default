﻿namespace Crossover.AMS.Contracts.Communication
{
    public interface IConferenceMessage : IMessage
    {
        long ConferenceId { get; }
    }
}