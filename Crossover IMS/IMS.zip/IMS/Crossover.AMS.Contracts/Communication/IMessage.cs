﻿using System;

namespace Crossover.AMS.Contracts.Communication
{
    public interface IMessage
    {
        long Id { get; }

        string Text { get; set; }

        string[] Attachments { get; }

        DateTime Sended { get; }

        Guid SenderSid { get; }
    }
}