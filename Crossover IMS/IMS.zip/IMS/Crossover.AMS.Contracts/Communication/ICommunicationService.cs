﻿using System;
using System.Collections.Generic;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace Crossover.AMS.Contracts.Communication
{
    [ServiceContract]
    public interface ICommunicationService
    {
        [OperationContract]
        void SendConferenceMessage(IConferenceMessage message);

        [OperationContract]
        [WebGet]
        void SendPrivateMessage(IPrivateMessage message);

        [OperationContract]
        IEnumerable<IPrivateMessage> GetPrivateMessages(Guid senderSid, Guid recipientSid);

        [OperationContract]
        IEnumerable<Guid> GetNewPrivateSenders(Guid recipientSid);

        [OperationContract]
        void MarkAsReaded(IPrivateMessage message);

        [OperationContract]
        IEnumerable<IConferenceMessage> GetConferenceMessages(long conferenceId);

        [OperationContract]
        [WebGet]
        IConference CreateConference(long accidentId, string title);

        [OperationContract]
        void UpdateConference(IConference conference);

        [OperationContract]
        void DeleteConference(long conferenceId);
    }
}