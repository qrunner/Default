namespace Crossover.AMS.Contracts.CrisisManagement
{
    public enum ResourceRequestState
    {
        New,
        Published,
        PartiallySatisfacted,
        FullySatisfacted,
    }
}