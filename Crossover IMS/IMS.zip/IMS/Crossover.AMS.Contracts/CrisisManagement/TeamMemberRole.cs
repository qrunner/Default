﻿namespace Crossover.AMS.Contracts.CrisisManagement
{
    public enum TeamMemberRole
    {
        Head,
        Supervisor,
        Member,
        CallCenterOperator
    }
}