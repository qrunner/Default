﻿namespace Crossover.AMS.Contracts.CrisisManagement
{
    public interface IEntity
    {
        long Id { get; }
    }
}
