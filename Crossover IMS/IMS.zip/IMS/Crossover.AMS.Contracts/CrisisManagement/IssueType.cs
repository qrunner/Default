﻿namespace Crossover.AMS.Contracts.CrisisManagement
{
    public enum IssueType
    {
        Assomplished,
        Risk
    }
}