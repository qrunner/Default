﻿namespace Crossover.AMS.Contracts.CrisisManagement
{
    public enum IssueCategory
    {
        Victim,
        Destruction,
        Contamination
    }
}