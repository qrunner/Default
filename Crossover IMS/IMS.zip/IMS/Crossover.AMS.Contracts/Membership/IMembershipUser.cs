﻿using System;

namespace Crossover.AMS.Contracts.Membership
{
    public interface IMembershipUser
    {
        Guid Sid { get; }

        string Login { get; }

        string DisplayName { get; }

        string Email { get; }
    }
}