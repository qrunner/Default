﻿namespace Crossover.AMS.Contracts
{
    public enum ContactType
    {
        Phone,
        Email,
        Website
    }
}