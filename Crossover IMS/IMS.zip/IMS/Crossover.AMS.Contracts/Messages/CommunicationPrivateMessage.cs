﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using Crossover.AMS.Contracts.Communication;

namespace Crossover.AMS.Contracts.Messages
{
    [DataContract]
    public class CommunicationPrivateMessage : IPrivateMessage
    {
        [DataMember]
        public long Id { get; private set; }

        [DataMember]
        public string Text { get; set; }

        [DataMember]
        public string[] Attachments { get; private set; }

        [DataMember]
        public DateTime Sended { get; private set; }

        [DataMember]
        public Guid SenderSid { get; private set; }

        [DataMember]
        public Guid RecipientSid { get; private set; }

        [DataMember]
        public bool Readed { get; private set; }
    }
}
