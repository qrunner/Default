﻿using System.Runtime.Serialization;
using Crossover.AMS.Contracts.Communication;

namespace Crossover.AMS.Contracts.Messages
{
    [DataContract]
    public class CommunicationConference : IConference
    {
        public long Id { get; set; }
        public string Title { get; set; }
        public ConferenceState State { get; set; }
    }
}